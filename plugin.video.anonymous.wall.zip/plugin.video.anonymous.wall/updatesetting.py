﻿#!/usr/bin/python
import os, sys, datetime, glob, shutil, urllib, filecmp, time
import xbmcaddon, xbmcgui, xbmc
import xml.etree.ElementTree as ET
import sync, logger
try:
	from sqlite3 import dbapi2 as database
except:
	from pysqlite2 import dbapi2 as database

def OKmsg(title, line1, line2="", line3=""):
	xbmcgui.Dialog().ok(title, line1, line2, line3)

def Source2DB(type,action,addpath):
	global AddonName,Addon
	filelist = glob.glob(xbmc.translatePath(os.path.join('special://home/userdata/Database','MyVideos*.db')))
	if filelist != []:
		for f in filelist:
			databaseFile=f
	else:
		return False

	print "*** {0}: Wall.Update.Setting: DB {1} {2}".format(AddonName,action, type)
	if type=="movies":
		q_add = "('special://userdata/addon_data/plugin.video.anonymous.wall/library/movies/','movies','metadata.themoviedb.org','',2147483647,0,'<settings><setting id=\"RatingS\" value=\"TMDb\" /><setting id=\"certprefix\" value=\"Rated \" /><setting id=\"fanart\" value=\"true\" /><setting id=\"keeporiginaltitle\" value=\"false\" /><setting id=\"language\" value=\""+Addon.getSetting("WallLanguage")+"\" /><setting id=\"tmdbcertcountry\" value=\"us\" /><setting id=\"trailer\" value=\"true\" /></settings>',0,0,NULL,NULL)"
	else:
		q_add = "('special://userdata/addon_data/plugin.video.anonymous.wall/library/tv/','tvshows','metadata.tvdb.com','',0,0,'<settings><setting id=\"RatingS\" value=\"TheTVDB\" /><setting id=\"absolutenumber\" value=\"false\" /><setting id=\"dvdorder\" value=\"false\" /><setting id=\"fallback\" value=\"true\" /><setting id=\"fanart\" value=\"true\" /><setting id=\"language\" value=\""+Addon.getSetting("WallLanguage")+"\" /></settings>',0,0,NULL,NULL)"
	dbcon = database.connect(databaseFile)
	dbcur = dbcon.cursor()
	if action=="add":
		try:
			q = "INSERT OR REPLACE INTO path (strPath,strContent,strScraper,strHash,scanRecursive,useFolderNames,strSettings,noUpdate,exclude,dateAdded,idParentPath) VALUES "+ q_add
			dbcur.execute(q)
			print "*** {0}: Wall.Update.Setting: DB Add Source".format(AddonName)
		except database.Error as e:
			print "MySQL Error :", e.args[0], q.decode("utf-8")
	elif action=="remove":
		try:
			dbcur.execute("DELETE FROM path WHERE strPath LIKE '%{0}%'".format(addpath))
			print "*** {0}: Wall.Update.Setting: DB Remove Source".format(AddonName)
		except database.Error as e:
			print "MySQL Error :", e.args[0]
	dbcon.commit()
	return

def Source2XML(xml_file,type,action,addpath):
	global AddonName
	tree = ET.parse(xml_file)
	root = tree.getroot()
	sources = root.find('video')

	for source in sources.findall('source'):
		xml_name = source.find("name").text
		xml_path = source.find("path").text

		if type=="movies" and xml_name == 'Movies Anonymous.Wall':
			if action=="add":
				return False
			elif action=="remove":
				sources.remove(source)
				tree.write(xml_file)
				print "*** {0}: Wall.Update.Setting: XML Remove Source".format(AddonName)
				return True
		elif type=="tv" and xml_name == 'TV Anonymous.Wall':
			if action=="add":
				return False
			elif action=="remove":
				sources.remove(source)
				tree.write(xml_file)
				print "*** {0}: Wall.Update.Setting: XML Remove Source".format(AddonName)
				return True

	if action=="add":
		new_source = ET.SubElement(sources, 'source')
		new_name = ET.SubElement(new_source, 'name')
		if type=="movies":
			new_name.text = 'Movies Anonymous.Wall'
		elif type=="tv":
			new_name.text = 'TV Anonymous.Wall'
		new_path = ET.SubElement(new_source, 'path')
		new_path.attrib['pathversion'] = "1"
		new_path.text = addpath
		tree.write(xml_file)
		print "*** {0}: Wall.Update.Setting: XML Add Source".format(AddonName)
		return True
	return False

def RemoveFolder(Folder):
	if os.path.isdir(Folder):
		try:
			shutil.rmtree(Folder)
			os.makedirs(Folder)
		except:
			pass

def CheckSettingUpdate(addonFolder):
	FileSetting = os.path.join(addonFolder,"settings.xml")
	BackupSetting = os.path.join(addonFolder,"library","settings.xml")
	if os.path.exists(FileSetting):
		if not os.path.exists(BackupSetting):
			if os.path.exists(FileSetting):
				if not os.path.exists(os.path.join(addonFolder,"library")):
					os.makedirs(os.path.join(addonFolder,"library"))
				shutil.copyfile(FileSetting,BackupSetting)
				return 1
			return 0
		else:
			if filecmp.cmp(FileSetting,BackupSetting):
				return 0
			else:
				shutil.copyfile(FileSetting,BackupSetting)
				return 1

def main():
	global AddonName,Addon
	addonID = "plugin.video.anonymous.wall"
	Addon = xbmcaddon.Addon(addonID)
	AddonName = Addon.getAddonInfo("name")
	localizedString = Addon.getLocalizedString

	if not CheckSettingUpdate(xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")):
		sys.exit(1)

	libraryFolder = "special://userdata/addon_data/plugin.video.anonymous.wall/library/"
	libraryFolderMovies = "special://userdata/addon_data/plugin.video.anonymous.wall/library/movies/"
	libraryFolderTV = "special://userdata/addon_data/plugin.video.anonymous.wall/library/tv/"
	xml_file = xbmc.translatePath(os.path.join('special://profile/','sources.xml'))
	
	streamMoviesAction = "add" if Addon.getSetting("useStreamMovies") == "true" else "remove"
	streamTVAction = "add" if Addon.getSetting("useStreamTV") == "true" else "remove"
	

	
	# If no sources.xml
	if not os.path.isfile(xml_file):
		urllib.urlretrieve ("https://raw.githubusercontent.com/kodianonymous1/Anonymous/master/sources.xml", xml_file)
		isXmlMoviesChanged = 1
		isXmlTVChanged = 1
	else:
		isXmlMoviesChanged = Source2XML(xml_file, "movies", streamMoviesAction, libraryFolderMovies)
		isXmlTVChanged = Source2XML(xml_file, "tv", streamTVAction, libraryFolderTV) 

	if isXmlMoviesChanged:
		Source2DB("movies",streamMoviesAction,libraryFolderMovies)

	if isXmlTVChanged:
		Source2DB("tv",streamTVAction,libraryFolderTV)

	# If disable remove library folder 
	if Addon.getSetting("useStreamMovies") == "false":
		RemoveFolder(libraryFolderMovies)
	if Addon.getSetting("useStreamTV") == "false":
		RemoveFolder(libraryFolderTV)

	if isXmlMoviesChanged or isXmlTVChanged:
		OKmsg("Anonymous Wall",localizedString(32005).encode('utf-8'),localizedString(32006).encode('utf-8'))
		sys.exit(1)
	else:
		sync.main()
		if Addon.getSetting("UploadLog") == "true":
			logger.main()